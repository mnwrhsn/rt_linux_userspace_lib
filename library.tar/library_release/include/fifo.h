struct fifo_node {
	struct fifo_node* next;
	int value;
};

struct fifo_node* fifo_init() {
	struct fifo_node* fifo_head = malloc(sizeof(struct fifo_node));
	fifo_head->next = NULL;
	fifo_head->value = 0;
	return fifo_head;
}

void fifo_enqueue(struct fifo_node* fifo_head, int value) {
	struct fifo_node* new_node = malloc(sizeof(struct fifo_node));
	new_node->next = NULL;
	new_node->value = value;

	struct fifo_node* cur = fifo_head;
	while (cur->next != NULL) {
		cur = cur->next;
	}
	cur->next = new_node;
}

int fifo_dequeue(struct fifo_node* fifo_head) {
	int ret = fifo_head->next->value;
	struct fifo_node* next_to_next = fifo_head->next->next;
	free(fifo_head->next);
	fifo_head->next = next_to_next;
	return ret;
}

int fifo_empty(struct fifo_node* fifo_head) {
	if (fifo_head->next == NULL) {
		return 1;
	}
	return 0;
}

int fifo_next(struct fifo_node** cur_address) {

	/* Use example
	 * struct fifo_node* cur = fifo_head;
	 * while (fifo_next(&cur)) {
	 * 	printf("%d\n",cur->value);
	 * }*/

	*cur_address = (*cur_address)->next;
	if (*cur_address == NULL) {
		return 0;
	}
	else {
		return 1;
	}
}

int fifo_peek(struct fifo_node* fifo_head) {
	return fifo_head->next->value;
}
