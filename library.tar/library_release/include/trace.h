/*******************************************************************************
Tracing Options
*******************************************************************************/

/* WARNING: You need to COMMENT OUT any of these to not trace them,
 * NOT define them as 0.
 */
#define _T_DO_TRACE_SWITCH_TO 1
#define _T_DO_TRACE_SWITCH_AWAY 1
#define _T_DO_TRACE_COMPLETION 1
#define _T_DO_TRACE_BEGIN_RELEASE_HANDLER 1
#define _T_DO_TRACE_END_RELEASE_HANDLER 1
#define _T_DO_TRACE_BEGIN_SCHEDULING 1
#define _T_DO_TRACE_END_SCHEDULING 1
#define _T_DO_TRACE_SEND_SIGNAL 1
#define _T_DO_TRACE_RECEIVE_SIGNAL 1
#define _T_DO_TRACE_EVENT_LATENCY 1
#define _T_DO_TRACE_DEBUG 1
#define _T_DO_TRACE_BEGIN_REQUEST_SIGNAL 1
#define _T_DO_TRACE_END_REQUEST_SIGNAL 1
/*
#define _T_DO_TRACE_START_UNBLOCK_SIGNALS 1
#define _T_DO_TRACE_END_UNBLOCK_SIGNALS 1
#define _T_DO_TRACE_START_BLOCK_SIGNALS 1
#define _T_DO_TRACE_END_BLOCK_SIGNALS 1
*/
#define _T_DO_TRACE_REQUEST_RESOURCE 1
#define _T_DO_TRACE_OBTAIN_RESOURCE 1
#define _T_DO_TRACE_SUSPEND 1
#define _T_DO_TRACE_RELEASE_RESOURCE 1

/*******************************************************************************
Public Function Declarations
*******************************************************************************/
void t_init_trace_buffer(int num_workers, int entries_per_worker);
void t_print_trace();
static inline unsigned long long t_rdtsc();
static inline int t_get_ticket(int worker);

static inline void T_TRACE_SWITCH_TO(int worker, int task, int job);
static inline void T_TRACE_SWITCH_AWAY(int worker, int task, int job);
static inline void T_TRACE_COMPLETION(int worker, int task, int job);
static inline void T_TRACE_BEGIN_RELEASE_HANDLER(int worker);
static inline void T_TRACE_END_RELEASE_HANDLER(int worker);
static inline void T_TRACE_BEGIN_SCHEDULING(int worker, int task, int job);
static inline void T_TRACE_END_SCHEDULING(int worker, int task, int job);
static inline void T_TRACE_SEND_SIGNAL(int worker, int destination);
static inline void T_TRACE_RECEIVE_SIGNAL(int worker);
static inline void T_TRACE_EVENT_LATENCY(int worker, long long latency);
static inline void T_TRACE_DEBUG(int worker, int one, int two, long long three);
static inline void T_TRACE_BEGIN_REQUEST_SIGNAL(int worker);
static inline void T_TRACE_END_REQUEST_SIGNAL(int worker);
static inline void T_TRACE_START_UNBLOCK_SIGNALS(int worker, int task);
static inline void T_TRACE_END_UNBLOCK_SIGNALS(int worker_for_ticket, int ticket, int task);
static inline void T_TRACE_START_BLOCK_SIGNALS(int worker_for_ticket, int ticket, int task);
static inline void T_TRACE_END_BLOCK_SIGNALS(int worker, int task);
static inline void T_TRACE_REQUEST_RESOURCE(int worker, int task);
static inline void T_TRACE_OBTAIN_RESOURCE(int worker, int task);
static inline void T_TRACE_SUSPEND(int worker, int task);
static inline void T_TRACE_RELEASE_RESOURCE(int worker, int task);

/*******************************************************************************
Private Function Declarations
*******************************************************************************/
static inline void _t_trace(int type, unsigned long long tsc, int worker, int task, int job, long long extra);
static inline void _t_trace_ticket(int type, unsigned long long tsc, int worker_for_ticket, int ticket, int task);

/*******************************************************************************
Data Declarations
*******************************************************************************/
int volatile *_t_wkr_buf_pos;
int volatile *_t_max_wkr_buf_pos;
int _t_num_workers;
int _t_num_entries_per_cpu;

struct _t_event_data
{
	int  type;
	unsigned long long tsc;
	int worker;
	int task;
	int job;
	long long extra;
};

struct _t_event_data *_t_trace_buffer;

/*******************************************************************************
Function Implementation
*******************************************************************************/
void t_init_trace_buffer(int workers, int entries) {

	_t_num_workers = workers;
	_t_num_entries_per_cpu = entries;

	_t_wkr_buf_pos                = malloc(_t_num_workers*sizeof(int));
	_t_max_wkr_buf_pos            = malloc(_t_num_workers*sizeof(int));

	/* set up params for each worker buf */
	for (int i=0; i < _t_num_workers; i++) {
		_t_wkr_buf_pos[i] = i * _t_num_entries_per_cpu;
		_t_max_wkr_buf_pos[i] = (i+1) * _t_num_entries_per_cpu;
	}

	_t_trace_buffer = malloc(_t_num_entries_per_cpu * _t_num_workers * sizeof(struct _t_event_data));
	if (_t_trace_buffer == NULL) {
		fprintf(stderr, "Could not malloc() trace buffer.\n");
		exit(1);
	}
}

static inline void T_TRACE_SWITCH_TO(int worker, int task, int job) {
	#ifdef _T_DO_TRACE_SWITCH_TO
	_t_trace(1, t_rdtsc(), worker, task, job, 0);
	#endif
}

static inline void T_TRACE_SWITCH_AWAY(int worker, int task, int job) {
	#ifdef _T_DO_TRACE_SWITCH_AWAY
	_t_trace(2, t_rdtsc(), worker, task, job, 0);
	#endif
}

static inline void T_TRACE_COMPLETION(int worker, int task, int job) {
	#ifdef _T_DO_TRACE_COMPLETION
	_t_trace(3, t_rdtsc(), worker, task, job, 0);
	#endif
}

static inline void T_TRACE_BEGIN_RELEASE_HANDLER(int worker) {
	#ifdef _T_DO_TRACE_BEGIN_RELEASE_HANDLER
	_t_trace(4, t_rdtsc(), worker, 0, 0, 0);
	#endif
}

static inline void T_TRACE_END_RELEASE_HANDLER(int worker) {
	#ifdef _T_DO_TRACE_END_RELEASE_HANDLER
	_t_trace(5, t_rdtsc(), worker, 0, 0, 0);
	#endif
}

static inline void T_TRACE_BEGIN_SCHEDULING(int worker, int task, int job) {
	#ifdef _T_DO_TRACE_BEGIN_SCHEDULING
	_t_trace(6, t_rdtsc(), worker, task, job, 0);
	#endif
}

static inline void T_TRACE_END_SCHEDULING(int worker, int task, int job) {
	#ifdef _T_DO_TRACE_END_SCHEDULING
	_t_trace(7, t_rdtsc(), worker, task, job, 0);
	#endif
}

static inline void T_TRACE_SEND_SIGNAL(int worker, int destination) {
	#ifdef _T_DO_TRACE_SEND_SIGNAL
	_t_trace(8, t_rdtsc(), worker, 0, 0, (long long)destination);
	#endif
}

static inline void T_TRACE_RECEIVE_SIGNAL(int worker) {
	#ifdef _T_DO_TRACE_RECEIVE_SIGNAL
	_t_trace(9, t_rdtsc(), worker, 0, 0, 0);
	#endif
}

static inline void T_TRACE_EVENT_LATENCY(int worker, long long latency) {
	#ifdef _T_DO_TRACE_EVENT_LATENCY
	_t_trace(10, t_rdtsc(), worker, 0, 0, latency);
	#endif
}

static inline void T_TRACE_DEBUG(int worker, int one, int two, long long three) {
	#ifdef _T_DO_TRACE_DEBUG
	_t_trace(11, t_rdtsc(), worker, one, two, three);
	#endif
}

static inline void T_TRACE_BEGIN_REQUEST_SIGNAL(int worker) {
	#ifdef _T_DO_TRACE_BEGIN_REQUEST_SIGNAL
	_t_trace(12, t_rdtsc(), worker, 0, 0, 0);
	#endif
}

static inline void T_TRACE_END_REQUEST_SIGNAL(int worker) {
	#ifdef _T_DO_TRACE_END_REQUEST_SIGNAL
	_t_trace(13, t_rdtsc(), worker, 0, 0, 0);
	#endif
}

static inline void T_TRACE_START_UNBLOCK_SIGNALS(int worker, int task) {
	#ifdef _T_DO_TRACE_START_UNBLOCK_SIGNALS
	_t_trace(14, t_rdtsc(), worker, task, 0, 0);
	#endif
}

static inline void T_TRACE_END_UNBLOCK_SIGNALS(int worker_for_ticket, int ticket, int task) {
	#ifdef _T_DO_TRACE_END_UNBLOCK_SIGNALS
	_t_trace_ticket(15, t_rdtsc(), worker_for_ticket, ticket, task);
	#endif
}

static inline void T_TRACE_START_BLOCK_SIGNALS(int worker_for_ticket, int ticket, int task) {
	#ifdef _T_DO_TRACE_START_BLOCK_SIGNALS
	_t_trace_ticket(16, t_rdtsc(), worker_for_ticket, ticket, task);
	#endif
}

static inline void T_TRACE_END_BLOCK_SIGNALS(int worker, int task) {
	#ifdef _T_DO_TRACE_END_BLOCK_SIGNALS
	_t_trace(17, t_rdtsc(), worker, task, 0, 0);
	#endif
}

static inline void T_TRACE_REQUEST_RESOURCE(int worker, int task) {
	#ifdef _T_DO_TRACE_REQUEST_RESOURCE
	_t_trace(18, t_rdtsc(), worker, task, 0, 0);
	#endif
}

static inline void T_TRACE_OBTAIN_RESOURCE(int worker, int task) {
	#ifdef _T_DO_TRACE_OBTAIN_RESOURCE
	_t_trace(19, t_rdtsc(), worker, task, 0, 0);
	#endif
}

static inline void T_TRACE_SUSPEND(int worker, int task) {
	#ifdef _T_DO_TRACE_SUSPEND
	_t_trace(20, t_rdtsc(), worker, task, 0, 0);
	#endif
}

static inline void T_TRACE_RELEASE_RESOURCE(int worker, int task) {
	#ifdef _T_DO_TRACE_RELEASE_RESOURCE
	_t_trace(21, t_rdtsc(), worker, task, 0, 0);
	#endif
}

static inline int t_get_ticket(int worker) {
	int ticket = _t_wkr_buf_pos[worker];
	_t_wkr_buf_pos[worker] += 1;
	if (_t_wkr_buf_pos[worker] > _t_max_wkr_buf_pos[worker]) {
		fprintf(stderr, "Overran trace buffer.\n");
		exit(1);
	}
	return ticket;
}

static inline void _t_trace(int type, unsigned long long tsc, int worker, int task, int job, long long extra) {
	_t_trace_buffer[_t_wkr_buf_pos[worker]].type = type;
	_t_trace_buffer[_t_wkr_buf_pos[worker]].tsc = tsc;
	_t_trace_buffer[_t_wkr_buf_pos[worker]].worker = worker;
	_t_trace_buffer[_t_wkr_buf_pos[worker]].task = task;
	_t_trace_buffer[_t_wkr_buf_pos[worker]].job = job;
	_t_trace_buffer[_t_wkr_buf_pos[worker]].extra = extra;
	_t_wkr_buf_pos[worker] += 1;
	if (_t_wkr_buf_pos[worker] > _t_max_wkr_buf_pos[worker]) {
		fprintf(stderr, "Overran trace buffer.\n");
		exit(1);
	}
}

static inline void _t_trace_ticket(int type, unsigned long long tsc, int worker_for_ticket, int ticket, int task) {
	_t_trace_buffer[ticket].type = type;
	_t_trace_buffer[ticket].tsc = tsc;
	_t_trace_buffer[ticket].worker = worker_for_ticket;
	_t_trace_buffer[ticket].task = task;
	_t_trace_buffer[ticket].job = 0;
	_t_trace_buffer[ticket].extra = 0;
}

void t_print_trace() {
	for (int i=0; i < _t_num_workers; i++) {
		for (int j=i * _t_num_entries_per_cpu; j < _t_wkr_buf_pos[i]; j++) {
			switch(_t_trace_buffer[j].type) {
				case (1):
					printf("SWITCH_TO %llu %d %d %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task, _t_trace_buffer[j].job);
					break;
				case (2):
					printf("SWITCH_AWAY %llu %d %d %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task, _t_trace_buffer[j].job);
					break;
				case (3):
					printf("COMPLETION %llu %d %d %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task, _t_trace_buffer[j].job);
					break;
				case (4):
					printf("BEGIN_RELEASE_HANDLER %llu %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker);
					break;
				case (5):
					printf("END_RELEASE_HANDLER %llu %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker);
					break;
				case (6):
					printf("BEGIN_SCHEDULING %llu %d %d %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task, _t_trace_buffer[j].job);
					break;
				case (7):
					printf("END_SCHEDULING %llu %d %d %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task, _t_trace_buffer[j].job);
					break;
				case (8):
					printf("SEND_SIGNAL %llu %d %lld\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].extra);
					break;
				case (9):
					printf("RECEIVE_SIGNAL %llu %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker);
					break;
				case (10):
					printf("EVENT_LATENCY %llu %d %lld\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].extra);
					break;
				case (11):
					printf("DEBUG %llu %d %d %d %lld\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task, _t_trace_buffer[j].job, _t_trace_buffer[j].extra);
					break;
				case (12):
					printf("BEGIN_REQUEST_SIGNAL %llu %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker);
					break;
				case (13):
					printf("END_REQUEST_SIGNAL %llu %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker);
					break;
				case (14):
					printf("START_UNBLOCK_SIGNALS %llu %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].task);
					break;
				case (15):
					printf("END_UNBLOCK_SIGNALS %llu %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].task);
					break;
				case (16):
					printf("START_BLOCK_SIGNALS %llu %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].task);
					break;
				case (17):
					printf("END_BLOCK_SIGNALS %llu %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].task);
					break;
				case (18):
					printf("REQUEST_RESOURCE %llu %d %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task);
					break;
				case (19):
					printf("OBTAIN_RESOURCE %llu %d %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task);
					break;
				case (20):
					printf("SUSPEND %llu %d %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task);
					break;
				case (21):
					printf("RELEASE_RESOURCE %llu %d %d\n", _t_trace_buffer[j].tsc, _t_trace_buffer[j].worker, _t_trace_buffer[j].task);
					break;


			}
		}
	}
}

/* WARNING: I don't know if this is actually correct, and/or on what
   architectures it is correct! */
static inline unsigned long long t_rdtsc() {
    unsigned int lo, hi;
    __asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
    return (unsigned long long)hi << 32 | lo;
}
