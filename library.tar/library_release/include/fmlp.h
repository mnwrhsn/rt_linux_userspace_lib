/*******************************************************************************
Todos
********************************************************************************
I think the following case may break currently:
   - task 1 requests and obtains A
   - task 1 requests B and is suspended
   - task 2 of priority higher than 1 requests A
   - task 1's prio is boosted - though it SHOULD be suspended.
*/

/* per-resource data */
struct fifo_node** fmlp_fifo_head;
int** fmlp_preempt_vector;
int* fmlp_res_is_short;
volatile int** fmlp_tsk_blocked_short_flag;

/* other data */
int fmlp_num_resources = 0;

/* functions */
void fmlp_create_resource(int is_short);
void fmlp_request(int resource);
void fmlp_release(int resource);

void fmlp_create_resource(int is_short) {
	fmlp_num_resources += 1;

	fmlp_fifo_head = realloc(fmlp_fifo_head,fmlp_num_resources * sizeof(struct fifo_node*));
	fmlp_fifo_head[fmlp_num_resources-1] = fifo_init();

	fmlp_preempt_vector = realloc(fmlp_preempt_vector, fmlp_num_resources * sizeof(int*));
	fmlp_preempt_vector[fmlp_num_resources-1] = malloc(_gedf_num_workers * sizeof(int));

	fmlp_res_is_short = realloc(fmlp_res_is_short, fmlp_num_resources * sizeof(int));
	fmlp_res_is_short[fmlp_num_resources-1] = is_short;

	fmlp_tsk_blocked_short_flag = realloc(fmlp_tsk_blocked_short_flag, fmlp_num_resources * sizeof(int*));
	fmlp_tsk_blocked_short_flag[fmlp_num_resources-1] = calloc(_gedf_num_tasks, sizeof(int));

}

void fmlp_request(int resource_id) {
	v_block_signals();

	int worker_id = (int)(long)pthread_getspecific(_v_worker_id_key);
	int task_id = _gedf_wkr_current_task[worker_id];
	T_TRACE_REQUEST_RESOURCE(worker_id, task_id);

	v_lock(&_gedf_lock);

	/* Add requesting task to the FMLP queue. */
	fifo_enqueue(fmlp_fifo_head[resource_id], task_id);

	/* Push its existing prio */
	stackarray_push(_gedf_tsk_priority_stack[task_id], _gedf_tsk_priority[task_id]);

	/* make non-preemptive if short */
	if (fmlp_res_is_short[resource_id]) {
		_gedf_change_task_priority(task_id, PRIO_NONPREEMPTIBLE);
	}

	/* If it's not the head, we need to suspend it. (Or spin, if it's short.) */
	int task_id_queue_head = fifo_peek(fmlp_fifo_head[resource_id]);
	if (task_id_queue_head != task_id) {
		if (fmlp_res_is_short[resource_id]) {
			fmlp_tsk_blocked_short_flag[resource_id][task_id] = 1;

			v_unlock(&_gedf_lock);

			while (fmlp_tsk_blocked_short_flag[resource_id][task_id] == 1);
		}
		else {
			/* prepare to run the preemption algorithm */
			_gedf_clear_preempt_vector(fmlp_preempt_vector[resource_id]);

			/* Store the current prio of the requester, then suspend it.
			 *
			 * We will need the current prio later so we can see if we need
			 * to priority boost the task at the head of the FMLP queue.
			 * Remember that the preemption check algorithm requires that
			 * if someone's priority will be lowered, it happen before any
			 * checks for updates are made. */
			_gedf_change_task_priority(task_id, PRIO_SUSPENDED);

			/* Since we lowered the prio of a task currently assigned to
			 * a CPU, we need to see if the highest-prio task (head of
			 * the ready queue) should take its place on the CPU. */
			int task_id_rq_head = _gedf_iheap_peek_value(&_gedf_tasks);
			_gedf_update_preempt_vector_for_task(task_id_rq_head, fmlp_preempt_vector[resource_id]);

			/* If needed, priority boost the task at the head of the FMLP
			 * queue. */
			if (stackarray_peek(_gedf_tsk_priority_stack[task_id]) < _gedf_tsk_priority[task_id_queue_head]) {
				_gedf_change_task_priority(task_id_queue_head,stackarray_peek(_gedf_tsk_priority_stack[task_id]));
				_gedf_update_preempt_vector_for_task(task_id_queue_head, fmlp_preempt_vector[resource_id]);
			}

			v_unlock(&_gedf_lock);

			T_TRACE_SUSPEND(worker_id, task_id);

			/* Trigger any resulting preemptions */
			_gedf_trigger_preemptions(worker_id, fmlp_preempt_vector[resource_id], 0);
		}
	}
	else {
		v_unlock(&_gedf_lock);
	}

	T_TRACE_OBTAIN_RESOURCE(worker_id, task_id);

	v_unblock_signals();
}

void fmlp_release(int resource_id) {

	v_block_signals();

	int worker_id = (int)(long)pthread_getspecific(_v_worker_id_key);
	int task_id = _gedf_wkr_current_task[worker_id];
	T_TRACE_RELEASE_RESOURCE(worker_id, task_id);

	v_lock(&_gedf_lock);

	fifo_dequeue(fmlp_fifo_head[resource_id]);

	_gedf_clear_preempt_vector(fmlp_preempt_vector[resource_id]);

	_gedf_change_task_priority(task_id, stackarray_pop(_gedf_tsk_priority_stack[task_id]));

	_gedf_update_preempt_vector_for_task(_gedf_iheap_peek_value(&_gedf_tasks), fmlp_preempt_vector[resource_id]);

	if (!fifo_empty(fmlp_fifo_head[resource_id])) {

		if (fmlp_res_is_short[resource_id]) {
			fmlp_tsk_blocked_short_flag[resource_id][fifo_peek(fmlp_fifo_head[resource_id])] = 0;
		}
		else {
			unsigned long long highest_prio = ULLONG_MAX;
			struct fifo_node* cur = fmlp_fifo_head[resource_id];
			while (fifo_next(&cur)) {
				if (stackarray_peek(_gedf_tsk_priority_stack[cur->value]) < highest_prio) {
					highest_prio = stackarray_peek(_gedf_tsk_priority_stack[cur->value]);
				}
			}

			_gedf_change_task_priority(fifo_peek(fmlp_fifo_head[resource_id]), highest_prio);

			_gedf_update_preempt_vector_for_task(fifo_peek(fmlp_fifo_head[resource_id]), fmlp_preempt_vector[resource_id]);
		}

	}

	v_unlock(&_gedf_lock);

	_gedf_trigger_preemptions(worker_id, fmlp_preempt_vector[resource_id], 0);

	v_unblock_signals();
}
