/*******************************************************************************
Function callbacks
*******************************************************************************/
#define gedf_release_handler policy_release_handler
#define gedf_preemption_handler policy_preemption_handler
#define gedf_proxy_exit_handler policy_proxy_exit_handler
#define gedf_task_harness task_harness

/*******************************************************************************
Public Function Declarations
*******************************************************************************/
void gedf_declare_task(unsigned long long phase, unsigned long long relative_deadline, unsigned long long period, int param, int func);
void gedf_declare_worker(int cpu);
void gedf_setup_state();
void gedf_prime_task_system_release();
void gedf_stop();
void gedf_release_handler(int signum);
void gedf_preemption_handler(int signum);
void gedf_proxy_exit_handler(int signum, siginfo_t *info, void *context);
void enter_proxy();


/*******************************************************************************
Private Function Declarations
*******************************************************************************/

/* call while holding gedf_lock */
void _gedf_update_task_to_worker_binding(int task_id, int worker_id);
void _gedf_change_task_priority(int task_id, unsigned long long new_priority);
void _gedf_update_preempt_vector_for_task(int task_id, int* preempt_vector);
int _gedf_iheap_peek_value(struct iheap* iheap);
int _gedf_task_is_assigned_to_worker(int task_id);
void _gedf_remove_from_heap(struct iheap* heap, int task_to_remove);

/* do not call while holding gedf_lock */
void _gedf_trigger_preemptions(int worker_id, int* preempt_vector, int do_trace);
void _gedf_schedule(int worker_id, int old_task_id, int is_completion, int already_have_lock);
void _gedf_after_switch_to(int task_id);

/* optionally call while holding gedf_lock */
void _gedf_clear_preempt_vector(int* preempt_vector);

/*******************************************************************************
Data Declarations
*******************************************************************************/

/* per-task variables: declarations */
unsigned long long *_gedf_tsk_declare_phase;
unsigned long long *_gedf_tsk_declare_relative_deadline;
unsigned long long *_gedf_tsk_declare_period;
int *_gedf_tsk_declare_param;
int *_gedf_tsk_declare_function;

/* per-task variables: task state */
unsigned long long *_gedf_tsk_relative_deadline;
unsigned long long *_gedf_tsk_period;
unsigned long long volatile *_gedf_tsk_release;
unsigned long long volatile *_gedf_tsk_priority;
int volatile *_gedf_tsk_job;
int volatile *_gedf_tsk_current_worker;
int *_gedf_tsk_param;
int *_gedf_tsk_function;
struct stackarray** _gedf_tsk_priority_stack;

/* per-task variables: impl details */
struct iheap_node *_gedf_tsk_hn;
struct iheap_node **_gedf_tsk_hn_ref;
int *_gedf_tsk_hn_value;

/* per-worker variables: delclarations  */
int *_gedf__wkr_declare_cpu;

/* per-worker variabes: worker state */
int *_gedf_release_handler_preempt_vector;
int *_gedf_proxy_handler_preempt_vector;
int volatile *_gedf_wkr_is_finished;
unsigned long long volatile *_gedf_wkr_effective_prio;
int volatile *_gedf_wkr_current_task;
int* _gedf_wkr_tsk_request_enter_proxy;

/* overall g-edf state */
struct iheap _gedf_tasks;
struct iheap _gedf_release;
int _gedf_num_workers = 0;
int _gedf_num_tasks = 0;
volatile int _gedf_lock = 0;
volatile int _gedf_terminate_run = 0;

/* special priorities */
#define PRIO_SUSPENDED ULLONG_MAX
#define PRIO_IDLE ULLONG_MAX-1
#define PRIO_NONPREEMPTIBLE 0

/*******************************************************************************
Function Definitions
*******************************************************************************/

int _gedf_iheap_peek_value(struct iheap* iheap) {
	struct iheap_node *selected = iheap_peek(iheap);
	int* iheap_value = (int *)selected->value;
	int task_id = *iheap_value;
	return task_id;
}

/* This is part of my special preemption algorith, which needs to be documented. */
void _gedf_clear_preempt_vector(int* preempt_vector) {
	for (int i=0; i < _gedf_num_workers; i++) {
		preempt_vector[i] = 0;
	}
}

/* This is part of my special preemption algorith, which needs to be documented. */
void _gedf_update_preempt_vector_for_task(int task_id, int* preempt_vector) {

	/* find the CPU with the minimum effective priority */
	unsigned long long min_effective_prio = 0; //start with infinitely "high" priority
	int min_effective_prio_cpu = 0;
	for (int i=0; i < _gedf_num_workers; i++) {
		if (_gedf_wkr_effective_prio[i] >= min_effective_prio) { //careful - lower prio means larger deadline
			min_effective_prio = _gedf_wkr_effective_prio[i];
			min_effective_prio_cpu = i;
		}
	}

	/* if that cpu has lower priority than this task, plan to preempt it and have this task run there instead */
	if (min_effective_prio > _gedf_tsk_priority[task_id]) {

		/* Setting _gedf_wkr_effective_prio here could cause someone to later see an "inaccurate" value, until the worker actually reschedules.
		 * However, if the worker has not yet rescheduled, we know that it will do so anyway, so someone seeing the "inaccurate" value--and, therefore, not
		 * causing the worker to be sent a preemption signal--does not matter. This could (rarely) cause a spurrious preemption of some other worker. */
		_gedf_wkr_effective_prio[min_effective_prio_cpu] = _gedf_tsk_priority[task_id]; //need locks to prevent racing on _gedf_wkr_effective_prio

		preempt_vector[min_effective_prio_cpu] = 1;
	}
}

/* This is part of my special preemption algorith, which needs to be documented. */
void _gedf_trigger_preemptions(int worker_id, int* preempt_vector, int do_trace) {
	if (do_trace) {
		T_TRACE_BEGIN_REQUEST_SIGNAL(worker_id);
	}
	for (int i=0; i < _gedf_num_workers; i++) {
		if (preempt_vector[i] && worker_id != i) {
			T_TRACE_SEND_SIGNAL(worker_id, i);
			v_pthread_kill(i);
		}
	}
	if (do_trace) {
		T_TRACE_END_REQUEST_SIGNAL(worker_id);
	}
	if (preempt_vector[worker_id]) {
		_gedf_schedule(worker_id, _gedf_wkr_current_task[worker_id], 0, 0);
	}
}


void gedf_release_handler(int signum) {

	int worker_id = v_get_worker();

	T_TRACE_BEGIN_RELEASE_HANDLER(worker_id);

	// call v_timer_fired_callback with timer_lock, as required.
	v_lock(&v_timer_lock);
	v_timer_fired_callback();
	v_unlock(&v_timer_lock);

	v_lock(&_gedf_lock);

	/* release tasks, and determine which cpus need preemption */
	_gedf_clear_preempt_vector(_gedf_release_handler_preempt_vector);
	while(!iheap_empty(&_gedf_release) && iheap_peek(&_gedf_release)->key < t_rdtsc()) {

		//remove from release queue
		struct iheap_node *selected = iheap_take(&_gedf_release);
		int* iheap_value = (int *)selected->value;
		int task_id = *iheap_value;
		T_TRACE_EVENT_LATENCY(worker_id, t_rdtsc() - _gedf_tsk_release[task_id]);

		//add this task to the ready queue
		iheap_node_init_ref(&_gedf_tsk_hn_ref[task_id], _gedf_tsk_priority[task_id], &_gedf_tsk_hn_value[task_id]);
		iheap_insert(&_gedf_tasks, &_gedf_tsk_hn[task_id]);

		_gedf_update_preempt_vector_for_task(task_id, _gedf_release_handler_preempt_vector);

	}

	/* re-arm the release timer */
	if (!iheap_empty(&_gedf_release)) {
		v_lock(&v_timer_lock);
		v_suggest_arm_timer(iheap_peek(&_gedf_release)->key);
		v_unlock(&v_timer_lock);
	}
	T_TRACE_END_RELEASE_HANDLER(worker_id);
	v_unlock(&_gedf_lock);

	/* request the needed preemptions elsewhere */
	_gedf_trigger_preemptions(worker_id, _gedf_release_handler_preempt_vector, 1);

}

void gedf_proxy_exit_handler(int signum, siginfo_t *info, void *context) {

	int task_id = info->si_value.sival_int;

	int worker_id = (int)(long)pthread_getspecific(_v_worker_id_key);

	v_lock(&_gedf_lock);
	_gedf_clear_preempt_vector(_gedf_proxy_handler_preempt_vector);
	_gedf_change_task_priority(task_id, _gedf_tsk_release[task_id] + _gedf_tsk_relative_deadline[task_id]);
	_gedf_update_preempt_vector_for_task(task_id, _gedf_proxy_handler_preempt_vector);
	v_unlock(&_gedf_lock);
	_gedf_trigger_preemptions(worker_id, _gedf_proxy_handler_preempt_vector, 0);
}

void gedf_preemption_handler(int signum) {

	int worker_id = (int)(long)pthread_getspecific(_v_worker_id_key);
	int task_id = _gedf_wkr_current_task[worker_id];
	T_TRACE_RECEIVE_SIGNAL(worker_id);

	/* NOTE: MAJOR CONCERN (though it seems to work)
	 * From GLIBC manual:
	 * It is not allowed to do the context switching from
	 * the signal handler directly since neither setcontext nor swapcontext
	 * are functions which can be called from a signal handler.
	 */
	_gedf_schedule(worker_id, task_id, 0, 0);

}

void _gedf_schedule(int worker_id, int old_task_id, int is_completion, int already_have_lock) {

	if (_gedf_terminate_run == 1) {
		T_TRACE_COMPLETION(_gedf_tsk_current_worker[old_task_id], old_task_id, _gedf_tsk_job[old_task_id]);
		_gedf_wkr_is_finished[_gedf_tsk_current_worker[old_task_id]] = 1;
		v_terminate_this_worker(worker_id, old_task_id);
	}

	/* the job_no variable is used to "backdate" job numbers if a task has just completed.
	 * it is only used for tracing purposes. */
	int job_no = (!is_completion ? _gedf_tsk_job[old_task_id] : _gedf_tsk_job[old_task_id] - 1);
	T_TRACE_BEGIN_SCHEDULING(worker_id, old_task_id, job_no);

	/* either prepare for a future release, or add to the ready queue. */
	if (!already_have_lock) {
		v_lock(&_gedf_lock);
	}

	if (_gedf_tsk_release[old_task_id] > t_rdtsc()) {
		/* We can only get here if this task just has a job completion,
		 * AND the next job of the task has not yet been released.
		 * In such a situation, we are definitely going to select a new
		 * task to switch to. */

		/* WARNING: Since there is no guarantee the timer will be armed, something could miss being released.
		 * TODO: Examine this more carefully and find a solution.
		 * Possible solution: Guarantee a preemption signal is sent if the timer is not armed? */

		v_lock(&v_timer_lock);
		v_suggest_arm_timer(_gedf_tsk_release[old_task_id]);
		v_unlock(&v_timer_lock);
		iheap_node_init_ref(&_gedf_tsk_hn_ref[old_task_id], _gedf_tsk_release[old_task_id], &_gedf_tsk_hn_value[old_task_id]);
		iheap_insert(&_gedf_release, &_gedf_tsk_hn[old_task_id]);


	}
	else {
		/* We could be here because schedule was called from the preemption handler, OR
		 * because the job finished after it's successor's release time. So, we may or
		 * may not need to switch to a new task. */

		if (!iheap_empty(&_gedf_tasks) && iheap_peek(&_gedf_tasks)->key < _gedf_tsk_priority[old_task_id]) {
			/* We need to switch, because smthg with strictly higher prio is in the ready queue.
			 * Note that the "strictly higher" qualification means PRIO_NONPREEMPTIVE tasks (in particular) are _never_ preempted. */
			iheap_node_init_ref(&_gedf_tsk_hn_ref[old_task_id], _gedf_tsk_priority[old_task_id], &_gedf_tsk_hn_value[old_task_id]);
			iheap_insert(&_gedf_tasks, &_gedf_tsk_hn[old_task_id]);
		}
		else {
			/* We don't need to switch, because there is nothing of strictly higher prio in the ready queue. */

			/* make sure the per-cpu priority is up to date. */
			_gedf_wkr_effective_prio[worker_id] = _gedf_tsk_priority[old_task_id];

			/* release the gedf lock and resume the task. */
			v_unlock(&_gedf_lock);

			/* Here, we don't use "job_no", so a task that completed and is going to immediately run again
			 * will BEGIN_SCHEDULING with the prior job number and END_SCHEDULING with the new one.*/
			T_TRACE_END_SCHEDULING(_gedf_tsk_current_worker[old_task_id], old_task_id, _gedf_tsk_job[old_task_id]);
			return;
		}
	}

	/* If we are at this point, we KNOW there is a task we need to switch to in the ready queue */

	/* remove highest prio task from the heap */
	struct iheap_node *selected = iheap_take(&_gedf_tasks);
	int* iheap_value = (int *)selected->value;
	int selected_task_id = *iheap_value;

	/* switch to it */
	_gedf_update_task_to_worker_binding(selected_task_id, worker_id);
	T_TRACE_END_SCHEDULING(_gedf_tsk_current_worker[old_task_id], old_task_id, job_no);
	T_TRACE_SWITCH_AWAY(worker_id, old_task_id, job_no);
	v_swapcontext(old_task_id,selected_task_id);

	/* this is where tasks resume after they have been preempted */
	_gedf_after_switch_to(old_task_id); //GOTCHA: you are old_task, not selected_task!

	return;

}

inline void _gedf_after_switch_to(int task_id) {

	if (_gedf_wkr_tsk_request_enter_proxy[_gedf_tsk_current_worker[task_id]] != 0) {
		union sigval value;
		value.sival_int = _gedf_wkr_tsk_request_enter_proxy[_gedf_tsk_current_worker[task_id]];
		sigqueue(getpid(), PROXY_ENTRY_SIGNAL, value);
		_gedf_wkr_tsk_request_enter_proxy[_gedf_tsk_current_worker[task_id]] = 0;
	}
	v_unlock(&_gedf_lock);
	T_TRACE_SWITCH_TO(_gedf_tsk_current_worker[task_id], task_id, _gedf_tsk_job[task_id]);
}


void _gedf_update_task_to_worker_binding(int task_id, int worker_id) {
	_gedf_wkr_current_task[worker_id] = task_id;
	_gedf_tsk_current_worker[task_id] = worker_id;
	_gedf_wkr_effective_prio[worker_id] = _gedf_tsk_priority[task_id];
}

/* This is a very nasty hack that I'm using due to apparent buggy behavior
 * from iheap_delete() and iheap_decrease().
 * TODO: Figure out and fix the problem, get rid of this nasty hack.
*/
void _gedf_remove_from_heap(struct iheap* heap, int task_to_remove) {

	struct fifo_node* fifo = fifo_init();
	struct iheap_node *selected;
	int* iheap_value;
	int task_id;

	while (!iheap_empty(heap)) {
		selected = iheap_take(heap);
		iheap_value = (int *)selected->value;
		task_id = *iheap_value;
		if (task_id != task_to_remove) {
			fifo_enqueue(fifo, task_id);
		}
	}

	while (!fifo_empty(fifo)) {
		task_id = fifo_dequeue(fifo);
		iheap_node_init_ref(&_gedf_tsk_hn_ref[task_id], _gedf_tsk_priority[task_id], &_gedf_tsk_hn_value[task_id]);
		iheap_insert(heap, &_gedf_tsk_hn[task_id]);
	}

	free(fifo);
}

void _gedf_change_task_priority(int task_id, unsigned long long new_priority) {
	_gedf_tsk_priority[task_id] = new_priority;
	if (_gedf_task_is_assigned_to_worker(task_id)) {
		_gedf_wkr_effective_prio[_gedf_tsk_current_worker[task_id]] = new_priority;
	}
	else {
		/* WARNING
		 * TODO
		 *
		 * With C-EDF and FMLP, we never change the prio of a task which
		 * is not either (a) assigned to a CPU, or (b) in the ready
		 * queue. So, if we are in this else clause, we can safely
		 * delete from and add back to the ready queue (in order to
		 * re-order the queue for the new priority).
		 *
		 * This assumption may not always be safe in the future. For
		 * example, it would fail if we ever want to change the priority
		 * of something in the release queue.*/

		_gedf_remove_from_heap(&_gedf_tasks, task_id);
		iheap_node_init_ref(&_gedf_tsk_hn_ref[task_id], _gedf_tsk_priority[task_id], &_gedf_tsk_hn_value[task_id]);
		iheap_insert(&_gedf_tasks, &_gedf_tsk_hn[task_id]);
	}
}

int _gedf_task_is_assigned_to_worker(int task_id) {
	return _gedf_wkr_current_task[_gedf_tsk_current_worker[task_id]] == task_id;
}

void gedf_declare_worker(int cpu) {

		_gedf_num_workers += 1;

		_gedf__wkr_declare_cpu = realloc(_gedf__wkr_declare_cpu, _gedf_num_workers * sizeof(int));
		_gedf__wkr_declare_cpu[_gedf_num_workers - 1] = cpu;

}

void gedf_declare_task(unsigned long long phase, unsigned long long relative_deadline, unsigned long long period, int param, int func) {

	_gedf_num_tasks += 1;

	_gedf_tsk_declare_phase = realloc(_gedf_tsk_declare_phase, _gedf_num_tasks * sizeof(unsigned long long));
	_gedf_tsk_declare_relative_deadline = realloc(_gedf_tsk_declare_relative_deadline, _gedf_num_tasks * sizeof(unsigned long long));
	_gedf_tsk_declare_period = realloc(_gedf_tsk_declare_period, _gedf_num_tasks * sizeof(unsigned long long));
	_gedf_tsk_declare_param = realloc(_gedf_tsk_declare_param, _gedf_num_tasks * sizeof(int));
	_gedf_tsk_declare_function = realloc(_gedf_tsk_declare_function, _gedf_num_tasks * sizeof(int));

	_gedf_tsk_declare_phase[_gedf_num_tasks - 1] = phase;
	_gedf_tsk_declare_relative_deadline[_gedf_num_tasks - 1] = relative_deadline;
	_gedf_tsk_declare_period[_gedf_num_tasks - 1] = period;
	_gedf_tsk_declare_param[_gedf_num_tasks - 1] = param;
	_gedf_tsk_declare_function[_gedf_num_tasks - 1] = func;

}

void gedf_setup_state() {

	/* malloc space for user-supplied params */
	_gedf_tsk_param		         = malloc(_gedf_num_tasks * sizeof(int));
	_gedf_tsk_relative_deadline      = malloc(_gedf_num_tasks * sizeof(unsigned long long));
	_gedf_tsk_period                 = malloc(_gedf_num_tasks * sizeof(unsigned long long));
	_gedf_tsk_release                = malloc(_gedf_num_tasks * sizeof(unsigned long long));
	_gedf_tsk_priority               = malloc(_gedf_num_tasks * sizeof(unsigned long long));
	_gedf_tsk_priority_stack         = malloc(_gedf_num_tasks * sizeof(struct stackarray*));
	_gedf_tsk_job                    = malloc(_gedf_num_tasks * sizeof(int));
	_gedf_tsk_current_worker         = malloc(_gedf_num_tasks * sizeof(int));
	_gedf_tsk_hn                     = malloc(_gedf_num_tasks * sizeof(struct iheap_node));
	_gedf_tsk_hn_ref                 = malloc(_gedf_num_tasks * sizeof(struct iheap_node*));
	_gedf_tsk_hn_value               = malloc(_gedf_num_tasks * sizeof(int));
	_gedf_tsk_function		 = malloc(_gedf_num_tasks * sizeof(int));

	/* for each task */
	for (int i=0; i < _gedf_num_tasks; i++) {

		_gedf_tsk_hn_value[i] = i;
		_gedf_tsk_hn_ref[i] = &_gedf_tsk_hn[i];
		iheap_node_init_ref(&_gedf_tsk_hn_ref[i], 0, &_gedf_tsk_hn_value[i]);
		_gedf_tsk_function[i] = _gedf_tsk_declare_function[i];

		if (i >= _gedf_num_workers) { //non-idle tasks
			/* initialize values based on user-supplied params */
			_gedf_tsk_release[i] = _gedf_tsk_declare_phase[i];
			_gedf_tsk_param[i] = _gedf_tsk_declare_param[i];
			_gedf_tsk_relative_deadline[i] = _gedf_tsk_declare_relative_deadline[i];
			_gedf_tsk_period[i] = _gedf_tsk_declare_period[i];

			/* further values */
			_gedf_tsk_priority[i] = _gedf_tsk_release[i] + _gedf_tsk_relative_deadline[i];
			_gedf_tsk_priority_stack[i] = stackarray_init();
			_gedf_tsk_job[i] = 1;
		}
		else { //idle tasks
			_gedf_tsk_release[i] = 0;
			_gedf_tsk_param[i] = 0;
			_gedf_tsk_relative_deadline[i] = 0;
			_gedf_tsk_period[i] = 0;
			_gedf_tsk_priority[i] = PRIO_IDLE;
			_gedf_tsk_job[i] = -1;
		}
	}

	/* heap */
	iheap_init(&_gedf_tasks);
	iheap_init(&_gedf_release);

	/* malloc space for worker params */
	_gedf_wkr_current_task              	       = malloc(_gedf_num_workers*sizeof(int));
	_gedf_wkr_effective_prio                       = malloc(_gedf_num_workers*sizeof(unsigned long long));
	_gedf_release_handler_preempt_vector           = malloc(_gedf_num_workers*sizeof(int));
	_gedf_proxy_handler_preempt_vector             = malloc(_gedf_num_workers*sizeof(int));
	_gedf_wkr_tsk_request_enter_proxy              = malloc(_gedf_num_workers*sizeof(int));
	_gedf_wkr_is_finished                          = malloc(_gedf_num_workers*sizeof(int));

	for (int i=0; i < _gedf_num_workers; i++) {

		/* set worker as not finished, prio of idle task (which is what it starts with) */
		_gedf_wkr_is_finished[i] = 0;
		_gedf_wkr_tsk_request_enter_proxy[i] = 0;
		_gedf_wkr_effective_prio[i] = PRIO_IDLE;

		/* Set which task is on this worker, to begin with */
		_gedf_update_task_to_worker_binding(i, i);
	}
}

void gedf_prime_task_system_release() {

	v_lock(&_gedf_lock);
	for (int i=_gedf_num_workers; i < _gedf_num_tasks; i++) {
		//long nsec = cycles_to_ns(_gedf_tsk_release[i] - rdtsc());
		//arm_release_timer(i, nsec);
		v_lock(&v_timer_lock);
		v_suggest_arm_timer(_gedf_tsk_release[i]);
		v_unlock(&v_timer_lock);
		iheap_node_init_ref(&_gedf_tsk_hn_ref[i], _gedf_tsk_release[i], &_gedf_tsk_hn_value[i]);
		iheap_insert(&_gedf_release, &_gedf_tsk_hn[i]);
	}
	v_unlock(&_gedf_lock);
}

void gedf_stop() {

	/* stop all proxy threads */
	v_terminate_run = 1;
	for (int i = 0; i < NUM_PROXY_THREADS; i++) {
		union sigval value;
		value.sival_int = 0;
		sigqueue(getpid(), PROXY_ENTRY_SIGNAL, value);
	}

	/* tell all workers to stop */
	_gedf_terminate_run = 1;
	for (int i = 0; i < _gedf_num_workers; i++) {
		v_pthread_kill(i);
	}


	/* make sure they really have */
	for (int i = 0; i < _gedf_num_workers; i++) {
		if (!_gedf_wkr_is_finished[i]) {
			i = -1;
			sleep(1);
		}
	}
}

static void gedf_task_harness(int task_id) {

	_gedf_after_switch_to(task_id);

	void (*func)(int,int,int);
	func = (void(*)(int,int,int))_gedf_tsk_function[task_id];

	while (1) {

		/* get trace tickets */
		int worker_for_ticket = _gedf_tsk_current_worker[task_id];
		int ticket1 = t_get_ticket(worker_for_ticket);
		int ticket2 = t_get_ticket(worker_for_ticket);

		/* unblock signals */
		T_TRACE_START_UNBLOCK_SIGNALS(_gedf_tsk_current_worker[task_id], task_id);
		v_unblock_signals();
		T_TRACE_END_UNBLOCK_SIGNALS(worker_for_ticket, ticket1, task_id);

		func(task_id, _gedf_tsk_job[task_id], _gedf_tsk_param[task_id]);

		/* block signals */
		T_TRACE_START_BLOCK_SIGNALS(worker_for_ticket, ticket2, task_id);
		v_block_signals();
		T_TRACE_END_BLOCK_SIGNALS(_gedf_tsk_current_worker[task_id], task_id);

		/* complete */
		/* TODO: The time from when signals are blocked onwards probably
		 * ideally should be counted as scheduling overhead. Right now,
		 * there is some un-accounted-for time.*/
		T_TRACE_COMPLETION(_gedf_tsk_current_worker[task_id], task_id, _gedf_tsk_job[task_id]);
		_gedf_tsk_release[task_id] = _gedf_tsk_release[task_id] + _gedf_tsk_period[task_id];
		_gedf_change_task_priority(task_id, _gedf_tsk_release[task_id] + _gedf_tsk_relative_deadline[task_id]);
		_gedf_tsk_job[task_id]++;
		_gedf_schedule(_gedf_tsk_current_worker[task_id], task_id, 1, 0);
	}

	fprintf(stderr,"SHOULD NEVER GET HERE\n");
	exit(1);
}

void enter_proxy() {

	v_block_signals();
	v_lock(&_gedf_lock);

	int worker_id = (int)(long)pthread_getspecific(_v_worker_id_key);
	int task_id = _gedf_wkr_current_task[worker_id];

	_gedf_change_task_priority(task_id, PRIO_SUSPENDED);

	_gedf_wkr_tsk_request_enter_proxy[worker_id] = task_id;
	/*fprintf(stderr,"%d",_gedf_wkr_tsk_request_enter_proxy[worker_id]);*/

	/* NOTE: already_have_lock is set */
	_gedf_schedule(worker_id, task_id, 0, 1);

}

void exit_proxy(int task_id) {

	/* this part happens in the proxy thread */
	fast_swapcontext(_v_tsk_ctx[task_id], _v_tsk_proxy_outer_ctx[task_id]);

	/* this happens later in _gedf_schedule and has to look (roughly) like the bottom of it */
	_gedf_after_switch_to(task_id);

	v_unblock_signals();
}
