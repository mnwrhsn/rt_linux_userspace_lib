/*******************************************************************************
Must be defined by policy
*******************************************************************************/
void policy_release_handler(int signum);
void policy_preemption_handler(int signum);
void policy_proxy_exit_handler(int signum, siginfo_t *info, void *context);
static void task_harness(int task_id);

/*******************************************************************************
Settings
*******************************************************************************/
/* there is a REAL danger of running over if you make this too small - it's happened to me!
 * running over will cause a very WTF seg fault. */
#define STACK_SIZE 1000000

#define V_MAX_TSK_CTX 500

/* you would think sending non-RT signals to release handler could cause some
 * releases to be lost, but AFAIK, I never saw that happen; I was losing
 * releases before I changed it from SIGALRM to SIGRTMIN, but I think due to a
 * different reason.
*/
#define RELEASE_SIGNAL SIGRTMIN

/* I don't know thwy, but setting this to be a RT signal causes a segfault. */
#define PREEMPTION_SIGNAL SIGUSR1

#define PROXY_ENTRY_SIGNAL SIGRTMIN+1
#define PROXY_EXIT_SIGNAL SIGRTMIN+2

/*******************************************************************************
Public Function Declarations
*******************************************************************************/
void v_setup_state();
void v_start_workers();
void v_create_ctx(int i);//, void (*func)(int));
void v_declare_worker(int cpu);
void v_swapcontext(int from, int to);
void v_suggest_arm_timer(unsigned long long proposed);
void v_timer_fired_callback();
void v_set_cycles_per_nanosecond(double cycles);
void v_lock(volatile int*);
void v_unlock(volatile int*);
void v_pthread_kill(int worker);
int v_get_worker();
void v_block_signals();
void v_unblock_signals();
void exit_proxy(int task_id);
void v_proxy_entry_handler(int signum, siginfo_t *info, void *context);
void v_start_proxy_threads(int num_proxy_threads);

/*******************************************************************************
Public Data Declarations
*******************************************************************************/
volatile int v_timer_lock = 0;
int v_terminate_run = 0;

/*******************************************************************************
Private Function Declarations
*******************************************************************************/
void _v_init_signal_handlers();
void* _v_worker_entry(void *worker_id_ptr);
void* _v_proxy_entry(void *task_id_ptr);
unsigned long long _v_cycles_to_ns(unsigned long long cycles);
extern int fast_swapcontext(ucontext_t*, ucontext_t*);
void _v_setaffinity(int cpu, pthread_t thread);
void _v_spawn_proxy_thread(int task_id);


/*******************************************************************************
Data Declarations
*******************************************************************************/

/* declaration stage */
int _v_num_workers = 0;
int *_v_wkr_declare_cpu;	      // holds declaration of cpu

/* per-task vars */
ucontext_t* _v_tsk_ctx[V_MAX_TSK_CTX];
ucontext_t* _v_tsk_proxy_outer_ctx[V_MAX_TSK_CTX];

/* per-worker vars */
ucontext_t **_v_wkr_ctx_ptr;     // where we save wkr's native context. we switch back to it upon termination.
volatile int *_v_wkr_cpu;      // worker's cpu
pthread_t **_v_wkr_pthread_ptr;  // pointer used to send sigs to a worker.

/* timer related, protected by v_timer_lock */
int _v_timer_is_armed = 0;
unsigned long long volatile _v_next_fire;

/* other */
pthread_key_t _v_worker_id_key;
timer_t _v_release_timer;
double _v_cycles_per_nanosecond;
int num_proxy_threads = 0;


/*******************************************************************************
Function Definitions
*******************************************************************************/

void v_start_proxy_threads(int _num_proxy_threads) {
	num_proxy_threads = _num_proxy_threads;
	for (int i=0; i < num_proxy_threads; i++) {
		_v_spawn_proxy_thread(0);
	}
}

void v_declare_worker(int cpu) {

	_v_num_workers += 1;

	_v_wkr_declare_cpu = realloc(_v_wkr_declare_cpu, _v_num_workers * sizeof(int));
	_v_wkr_declare_cpu[_v_num_workers-1] = cpu;
}


void v_setup_state() {

	/* Normally, this would need to be lock-protected, but at this point, the
	 * code is presumed to be single-threaded anyway.
	 */
	_v_timer_is_armed = 0;

	/* Lock all memory */
	int rc = mlockall(MCL_CURRENT | MCL_FUTURE);
	if (rc != 0) {
		handle_error_en(rc, "mlockall");
	}

	/* Set SCHED_FIFO priority.
	 * Experiment thread should have slightly higher priority than the worker threads. */
	int policy = SCHED_FIFO;
	struct sched_param param;
	param.sched_priority = sched_get_priority_min(policy)+1;
	rc = pthread_setschedparam(pthread_self(), policy, &param);
	if (rc != 0) {
		handle_error_en(rc, "pthread_setschedparam");
	}

	/* Block all signals.
	 *
	 * Signal masks are per-thread. (However, the thread's signal mask is
	 * replaced in the stock swapcontext(), which we have replaced with a
	 * version that does not do this.)
	 *
	 * Thus, by blocking here, we are blocking automatically in the spawned
	 * workers.
	 *
	 * Pending signals are also per-thread, and never travel with the
	 * context (neither in the stock swapcontext() or in our replacement).*/
	v_block_signals();

	/* Linux's clone() (used by glibc pthreads) allows the signal handler table to be copied
	 * by spawned threads, or to be referenced by them. Glibc pthreads does it by
	 * reference. So, we can set our signal handlers up anywhere; might as well do it
	 * here. */
	_v_init_signal_handlers();

	// set up release timer
	struct sigevent sev;
	sev.sigev_signo = RELEASE_SIGNAL;
   	sev.sigev_notify = SIGEV_SIGNAL;
	sev.sigev_value.sival_ptr = &_v_release_timer;
	if (timer_create(CLOCK_REALTIME, &sev, &_v_release_timer) != 0) {
		handle_error_en(errno, "timer_create");
	}

	/* create pthread-local key */
	pthread_key_create(&_v_worker_id_key, NULL);

	/* Declare space for all worker params */
	_v_wkr_cpu   		   = malloc(_v_num_workers*sizeof(int));
	_v_wkr_pthread_ptr            = malloc(_v_num_workers*sizeof(ucontext_t*)); //I think this sizeof() is a mistake.
	_v_wkr_ctx_ptr                = malloc(_v_num_workers*sizeof(ucontext_t*));

	/* set per-worker data */
	pthread_t *thread;
	for (int i=0; i < _v_num_workers; i++) {

		/* malloc space for pthread data */
		thread = malloc(sizeof(pthread_t));

		/* save ptr to pthread_t for signal sending. */
		_v_wkr_pthread_ptr[i] = thread;

		/* set initial cpu */
		_v_wkr_cpu[i] = _v_wkr_declare_cpu[i];

		/* malloc space for worker context */
		_v_wkr_ctx_ptr[i] = malloc(sizeof(ucontext_t));


	}

}

void v_start_workers() {
	for (int i=0; i < _v_num_workers; i++) {
		/* create thread */
		/* it's funny that this works even though worker_id is local to this function; guess it does not */
		/* get cleared from the stack. */
		int rc = pthread_create(_v_wkr_pthread_ptr[i], NULL, _v_worker_entry, (void *)(long)i);
		if (rc != 0)
			handle_error_en(rc, "pthread_create");

		/* set affinity for thread */
		_v_setaffinity(_v_wkr_cpu[i], *_v_wkr_pthread_ptr[i]);
	}
}

void v_create_ctx(int i) {//, void (*func)(int)) {
	_v_tsk_ctx[i] = malloc(sizeof(ucontext_t));
	getcontext(_v_tsk_ctx[i]);
	_v_tsk_ctx[i]->uc_link = NULL;
	_v_tsk_ctx[i]->uc_stack.ss_sp = malloc(STACK_SIZE);
	if (_v_tsk_ctx[i]->uc_stack.ss_sp == 0) {
		fprintf(stderr,"Could not get stack.\n");
		exit(1);
	}
	_v_tsk_ctx[i]->uc_stack.ss_size = STACK_SIZE;
	makecontext(_v_tsk_ctx[i],(void (*) (void)) &task_harness, 1, i);

	_v_tsk_proxy_outer_ctx[i] = malloc(sizeof(ucontext_t));
}

void v_set_cycles_per_nanosecond(double cycles) {
	_v_cycles_per_nanosecond = cycles;
}

void *_v_worker_entry(void *worker_id_ptr) {

	int worker_id = (int)(long)worker_id_ptr;

	/* set thread-specific worker_id_key */
	pthread_setspecific(_v_worker_id_key, (void *)(long)worker_id);

	/* wait for task to migrate to proper cpu */
	/* warning: if the condition is never satisfied, the thread will just spin... */
	while (_v_wkr_cpu[worker_id] != sched_getcpu());

	/* become real-time priority */
	int policy = SCHED_FIFO;
	struct sched_param param;
	param.sched_priority = sched_get_priority_min(policy);
	int rc = pthread_setschedparam(pthread_self(), policy, &param);
	if (rc != 0) {
		handle_error_en(rc, "pthread_setschedparam");
	}

	/* This is policy specific and should be removed eventually.
	 * Probably, I'll move it once the user can provide function ptrs specific
	 * to each task. Then, the regular tasks would have immediate unlock() calls,
	 * the idle tasks would not */
	//lock(&gedf_lock);
	/* Update: Right now I just assume the policy waits until all workers have definitely
	 * started before it starts scheduling. I probably should make some kind of
	 * explicit guarantee... i.e. each idle task checks in and it waits until there
	 * are enough... or something. */

	/* switch to the task with id that matches the worker's id */
	fast_swapcontext(_v_wkr_ctx_ptr[worker_id],_v_tsk_ctx[worker_id]);


	/* We get here after v_terminate_this_thread().
	 * return NULL is equiv. to calling pthread_exit(NULL). */
	 pthread_exit(NULL);
}


void* _v_proxy_entry(void *task_id_ptr) {

	/*int task_id = (int)(long)task_id_ptr;*/

	/* Unblock the proxy entry signal */
	sigset_t set;
	int rc;
	sigemptyset(&set);
	sigaddset(&set, PROXY_ENTRY_SIGNAL);
	rc = pthread_sigmask(SIG_UNBLOCK, &set, NULL);
	if (rc != 0) {
		handle_error_en(rc, "pthread_sigmask");
	}

	while (!v_terminate_run) {
		pause();
	}

	pthread_exit(NULL);

}

void v_proxy_entry_handler(int signum, siginfo_t *info, void *context) {

	if (v_terminate_run) {
		/* If you return here, the same proxy can get the
		 * signal used to terminate multiple times, preventing
		 * a different proxy from getting it... */
		pthread_exit(NULL);
	}

	int task_id = info->si_value.sival_int;

	fast_swapcontext(_v_tsk_proxy_outer_ctx[task_id],_v_tsk_ctx[task_id]);

	/* this happens after proxy_exit() has caused the worker ctx to begin executing again */

	union sigval value;
	value.sival_int = task_id;

	if (!v_terminate_run) {
		sigqueue(getpid(), PROXY_EXIT_SIGNAL, value);
	}

	return;

}

/* Only arms the timer if the proposed new time is before the existing time (if
 * any).
 *
 * REQUIREMENT: Must be called with the v_timer_lock held.
 * REQUIREMENT: After the timer fires, the recipient must call v_timer_fired_callback().
 */
void v_suggest_arm_timer(unsigned long long proposed) {
	if (!_v_timer_is_armed || proposed < _v_next_fire) {
		long long far_offset = _v_cycles_to_ns(proposed - t_rdtsc());
		long offset = (far_offset > 999999999 ? 999999999 : far_offset);
		if (offset > 0) {

			struct itimerspec timerspec;
			timerspec.it_value.tv_nsec=offset;
			timerspec.it_value.tv_sec = 0;
			timerspec.it_interval.tv_nsec=0;
			timerspec.it_interval.tv_sec = 0;

			if (timer_settime(_v_release_timer, 0, &timerspec, NULL) != 0) {
				handle_error_en(errno, "timer_settime");
			}

			_v_next_fire = proposed;
			_v_timer_is_armed = 1;

		}
	}
}

/* Reset the next firing time of the timer.
*
* REQUIREMENT: Must be called with the v_timer_lock held.
* REQUIREMENT: Must be called when timer signal received.
*/
inline void v_timer_fired_callback() {
	_v_timer_is_armed = 0;
}

inline void v_pthread_kill(int worker) {
	pthread_kill(*_v_wkr_pthread_ptr[worker], PREEMPTION_SIGNAL);
}

inline int v_get_worker() {
	return (int)(long)pthread_getspecific(_v_worker_id_key);
}

void _v_init_signal_handlers() {

	struct sigaction act;
	sigset_t set; //other signals to block while this signal's handler executes
	act.sa_flags = SA_SIGINFO;

	//release handler
	act.sa_handler = policy_release_handler;
	sigemptyset(&set);
	sigaddset(&set, RELEASE_SIGNAL);
	sigaddset(&set, PREEMPTION_SIGNAL);
	sigaddset(&set, PROXY_ENTRY_SIGNAL);
	sigaddset(&set, PROXY_EXIT_SIGNAL);
	act.sa_mask = set;
	if (sigaction(RELEASE_SIGNAL, &act, NULL) != 0) {
		handle_error_en(errno, "sigaction");
	}

	//preemption handler
	act.sa_handler = policy_preemption_handler;
	sigemptyset(&set);
	sigaddset(&set, RELEASE_SIGNAL);
	sigaddset(&set, PREEMPTION_SIGNAL);
	sigaddset(&set, PROXY_ENTRY_SIGNAL);
	sigaddset(&set, PROXY_EXIT_SIGNAL);
	act.sa_mask = set;
	if (sigaction(PREEMPTION_SIGNAL, &act, NULL) != 0) {
		handle_error_en(errno, "sigaction");
	}


	//proxy entry handler
	act.sa_sigaction = v_proxy_entry_handler;
	sigemptyset(&set);
	sigaddset(&set, RELEASE_SIGNAL);
	sigaddset(&set, PREEMPTION_SIGNAL);
	sigaddset(&set, PROXY_ENTRY_SIGNAL);
	sigaddset(&set, PROXY_EXIT_SIGNAL);
	act.sa_mask = set;
	if (sigaction(PROXY_ENTRY_SIGNAL, &act, NULL) != 0) {
		handle_error_en(errno, "sigaction");
	}

	//proxy exit handler
	act.sa_sigaction = policy_proxy_exit_handler;
	sigemptyset(&set);
	sigaddset(&set, RELEASE_SIGNAL);
	sigaddset(&set, PREEMPTION_SIGNAL);
	sigaddset(&set, PROXY_ENTRY_SIGNAL);
	sigaddset(&set, PROXY_EXIT_SIGNAL);
	act.sa_mask = set;
	if (sigaction(PROXY_EXIT_SIGNAL, &act, NULL) != 0) {
		handle_error_en(errno, "sigaction");
	}

}

void v_terminate_this_worker(int worker_id, int task_id) {
	fast_swapcontext(_v_tsk_ctx[task_id],_v_wkr_ctx_ptr[worker_id]);
}

void v_swapcontext(int from, int to) {
	fast_swapcontext(_v_tsk_ctx[from],_v_tsk_ctx[to]);
}

void v_block_signals() {
	sigset_t set;
	int rc;
	sigemptyset(&set);
	sigaddset(&set, RELEASE_SIGNAL);
	sigaddset(&set, PREEMPTION_SIGNAL);
	sigaddset(&set, PROXY_ENTRY_SIGNAL);
	sigaddset(&set, PROXY_EXIT_SIGNAL);
	rc = pthread_sigmask(SIG_BLOCK, &set, NULL);
	if (rc != 0) {
		handle_error_en(rc, "pthread_sigmask");
	}
}

void v_unblock_signals() {
	sigset_t set;
	int rc;
	sigemptyset(&set);
	sigaddset(&set, RELEASE_SIGNAL);
	sigaddset(&set, PREEMPTION_SIGNAL);
	sigaddset(&set, PROXY_EXIT_SIGNAL);
	rc = pthread_sigmask(SIG_UNBLOCK, &set, NULL);
	if (rc != 0) {
		handle_error_en(rc, "pthread_sigmask");
	}
}

void _v_setaffinity(int cpu, pthread_t thread) {
	cpu_set_t cpuset;
	CPU_ZERO(&cpuset);
	CPU_SET(cpu, &cpuset);
	int rc = pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);
	if (rc != 0)
		handle_error_en(rc, "pthread_setaffinity_np");
}

void _v_spawn_proxy_thread(int task_id) {

	pthread_t pthread;
	pthread_attr_t attr;
	pthread_attr_t* attrp; //use in call to pthread_create
	attrp = &attr;

	int rc;

	/* need to set attrs */
	rc = pthread_attr_init(&attr);
	if (rc != 0) {
		handle_error_en(rc, "pthread_attr_init");
	}
	int policy = SCHED_FIFO;
	struct sched_param param;
	param.sched_priority = sched_get_priority_min(policy)+1;
	rc = pthread_attr_setschedpolicy(&attr, policy);
	if (rc != 0)
		handle_error_en(rc, "pthread_attr_setschedpolicy");
	rc = pthread_attr_setschedparam(&attr, &param);
	if (rc != 0)
		handle_error_en(rc, "pthread_attr_setschedparam");
	/* create the pthread */
	rc = pthread_create(&pthread, attrp, _v_proxy_entry, (void *)(long)task_id);
	if (rc != 0)
		handle_error_en(rc, "pthread_create");
}


/*******************************************************************************
Spin Lock (TODO: Taken from StackOverflow, so I shouldn't assume it's correct.)
*******************************************************************************/

/* I use spin locks rather than pthread mutexes because pthread mutexes are
 * implemented with futexes underneath, which are extermely efficient in the
 * case of non-contention, but which cause processes to be swapped out for
 * something else in the case of contention. (see man 7 pthreads)
 *
 * Note: lock variables should be declared as: volatile int lockname = 0;
*/

void v_lock(volatile int *lockvar_ptr) {
    while (__sync_lock_test_and_set(lockvar_ptr, 1)) {
        // Do nothing. This GCC builtin instruction
        // ensures memory barrier.
    }
}

void v_unlock(volatile int *lockvar_ptr) {
    __sync_synchronize(); // Memory barrier.
    *lockvar_ptr = 0;
}

/*******************************************************************************
TIME
*******************************************************************************/

/* Returning something larger than a long is necessary if you're compiling
 * on 32 bit, because a long can only specify ~4 seconds of duration in
 * nanoseconds without overflowing. */
unsigned long long _v_cycles_to_ns(unsigned long long cycles) {
	long double result = cycles / _v_cycles_per_nanosecond;
	return (unsigned long long)result;
}


