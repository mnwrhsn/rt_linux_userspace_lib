#define MAX_STACK_SIZE 20


struct stackarray {
	unsigned long long stack[MAX_STACK_SIZE];
	int top;
};

struct stackarray* stackarray_init() {
	struct stackarray* stackarray = malloc(sizeof(struct stackarray));
	stackarray->top = -1;
	return stackarray;
}

void stackarray_push(struct stackarray* stackarray, unsigned long long value) {
	stackarray->top += 1;
	if (stackarray->top == MAX_STACK_SIZE) {
		fprintf(stderr,"FATAL ERROR: Tried to grow stack too large.\n");
		exit(1);
	}
	stackarray->stack[stackarray->top] = value;
}

unsigned long long stackarray_pop(struct stackarray* stackarray) {
	if (stackarray->top == -1) {
		fprintf(stderr,"FATAL ERROR: Tried to pop from empty stack.\n");
		exit(1);
	}
	unsigned long long value;
	value = stackarray->stack[stackarray->top];
	stackarray->top -= 1;
	return value;
}

unsigned long long stackarray_peek(struct stackarray* stackarray) {
	if (stackarray->top == -1) {
		fprintf(stderr,"FATAL ERROR: Tried to peek empty stack.\n");
		exit(1);
	}
	return stackarray->stack[stackarray->top];
}

/* SAMPLE PROGRAM
	struct stackarray* stackarray = stackarray_init();
	unsigned long long value1 = 234234234;
	unsigned long long value2 = 666;
	unsigned long long value3 = 7;
	stackarray_push(stackarray,value1);
	stackarray_push(stackarray,value2);
	stackarray_push(stackarray,value3);
	printf("%llu\n", stackarray_pop(stackarray));
	printf("%llu\n", stackarray_pop(stackarray));
	printf("%llu\n", stackarray_pop(stackarray));
	stackarray_push(stackarray,value1);
	stackarray_push(stackarray,value2);
	printf("%llu\n", stackarray_pop(stackarray));
	printf("%llu\n", stackarray_pop(stackarray));
	printf("%llu\n", stackarray_pop(stackarray)); //fatal error
	exit(1);
*/
