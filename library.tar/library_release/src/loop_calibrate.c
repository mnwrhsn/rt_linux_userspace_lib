#include <stdio.h>
#include <stdlib.h>

#define SCRATCH_SIZE 4096
void new_work_loop(int iterations) {
	volatile int nums[SCRATCH_SIZE];
	for (int i=0; i < iterations; i++) {
		for (int j=0; j < SCRATCH_SIZE; j++) {
			nums[j] += 1;
			nums[j] *= 77;
		}
	}
}

void work_loop(int iterations) {

	/* without the "register" qualifier, cache effects cause unpredictable runtime. */
	register int iters = iterations;

	/* without the "volatile" qualifier, GCC optimizes out the loop with sufficient optimization level. */
	for (volatile int i=0; i < iters; i++);

}

#define CYCLES_PER_NANOSECOND 2.493863

unsigned long long ms_to_cycles(int msec) {
	return CYCLES_PER_NANOSECOND * 1000000 * msec;
}

double cycles_to_ms(unsigned long long cycles) {
	return (cycles / CYCLES_PER_NANOSECOND) / 1000000;
}

static inline unsigned long long rdtsc() {
    unsigned int lo, hi;
    __asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
    return (unsigned long long)hi << 32 | lo;
}

int main(int argc, char *argv[]) {
	unsigned long long start;
	unsigned long long end;
	double delta = 0;

	start = rdtsc();
	//work_loop(100000000);
	new_work_loop(100000);
	end = rdtsc();
	delta = cycles_to_ms(end - start);
	printf("%f\n",100000/delta);
	//printf("%f\n",100000000/delta);

}
