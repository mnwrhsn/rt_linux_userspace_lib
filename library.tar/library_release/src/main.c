/*******************************************************************************
GENERALIZED THINGS TO DO (others are scattered throughout code)
*******************************************************************************/
/*

TODO: Consider making functions INLINE (and/or static?)

*/

/*******************************************************************************
Options
*******************************************************************************/
#define INITIAL_DELAY_MS 3000
#define TRACE_ENTRIES_PER_WORKER 10000000
#define NUM_PROXY_THREADS 8

/*******************************************************************************
Includes
*******************************************************************************/

// TODO: These may need to be moved into trace.h, v.n, gedf.h as appropriate.
// I originally added this because it causes an implicit declaration warning for sched_getcpu() to go away.
// the NOTES file in the glibc source appears to be a good reference on the meaning of this.
#define _GNU_SOURCE

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h> //for exit()
#include <sched.h>  //for sched_getcpu()
#include <errno.h>  //for handle_error_en()
#include <ucontext.h> //for ucontext
#include <unistd.h> //for sleep
#include <limits.h> //for iheap.h
#include <time.h>   //for release timer
#include "signal.h" //for signals
#include <sys/mman.h>
#include <math.h>

#define handle_error_en(en, msg) \
       do { errno = en; perror(msg); exit(EXIT_FAILURE); } while (0)

#include "trace.h"
#include "iheap.h"  //for binomial heaps, courtesy bbb
#include "v.h"
#include "stackarray.h"
#include "fifo.h"
#include "gedf.h"
#include "fmlp.h"

/*******************************************************************************
Data declarations
*******************************************************************************/
unsigned long long time_zero;
double cycles_per_nanosecond;
int experiment_length;
int num_workers = 0;
int num_tasks;

/*******************************************************************************
Function declarations
*******************************************************************************/
unsigned long long ms_to_cycles(double msec);
double cycles_to_ms(unsigned long long cycles);
void init_config_params(int argc, char* argv[]);
void work_loop(int task_id, int job_no, int param);
void idle_function(int task_id, int job_no, int param);

/*******************************************************************************
Global variables
*******************************************************************************/
int iterations_per_ms;

/*******************************************************************************
STUFF THAT RUNS IN MAIN CONTROL THREAD
*******************************************************************************/

int main(int argc, char *argv[])
{
	/* Parse configuration params that are not worker or task specific. */
	init_config_params(argc, argv);

	/* tracing */
	t_init_trace_buffer(num_workers, TRACE_ENTRIES_PER_WORKER);

	/* workers */
	for (int i = 0, cpu; i < num_workers; i++) {
		cpu = atoi(argv[5+i]);
		v_declare_worker(cpu);
		gedf_declare_worker(cpu);
	}

	/* tasks */
	unsigned long long phase, relative_deadline, period;
	int param, offset;
	for (int i=0; i < num_tasks; i++) {
		v_create_ctx(i);
		if (i < num_workers) {
			phase = 0;
			relative_deadline = 0;
			period = 0;
			param = 0;
			gedf_declare_task(phase, relative_deadline, period, param, (int) &idle_function);
		}
		else {
			offset = 5 + num_workers + (i-num_workers)*4;
			phase = time_zero + ms_to_cycles(atof(argv[offset]));
			param = atoi(argv[offset+1]);
			relative_deadline = ms_to_cycles(atof(argv[offset+2]));
			period = ms_to_cycles(atof(argv[offset+3]));
			gedf_declare_task(phase, relative_deadline, period, param, (int) &work_loop);
		}
	}

	v_setup_state();
	gedf_setup_state();

	/* create some FMLP resources, for testing */
	fmlp_create_resource(1);
	fmlp_create_resource(1);
	fmlp_create_resource(1);
	fmlp_create_resource(0);
	fmlp_create_resource(0);
	fmlp_create_resource(0);

	v_start_workers();
	v_start_proxy_threads(NUM_PROXY_THREADS);
	gedf_prime_task_system_release();

	if (experiment_length==0) {
		sleep(-1);
	}
	else {
		sleep(experiment_length + cycles_to_ms(time_zero - t_rdtsc()) / 1000);
	}

	gedf_stop();

	t_print_trace();

	/* The following call will cause the main thread to idle until all
	 * spawned workers have been cleand up (which should have happened already). */
	pthread_exit(NULL);
}

void init_config_params(int argc, char* argv[]) {

	/* WARNING: It is INCREDIBLY important that CYCLES_PER_NS be set
	 * correctly, because it is the basis for setting timers. By fixing
	 * this, I have seen max event latency drop from >100 us to <20 us, for
	 * initial task release (which is typically "far in the future" when the
	 * timer is set and thus subject to more error). FYI, this number
	 * changes every time the machine is rebooted!*/
	cycles_per_nanosecond = atof(argv[1]);

	time_zero = t_rdtsc() + ms_to_cycles(INITIAL_DELAY_MS);

	v_set_cycles_per_nanosecond(cycles_per_nanosecond);

	iterations_per_ms = atoi(argv[2]);
	experiment_length = atoi(argv[3]);
	num_workers = atoi(argv[4]);
	int num_user_tasks = (argc - 5 - num_workers) / 4;
	num_tasks = num_user_tasks + num_workers;
}

/*******************************************************************************
STUFF THAT RUNS IN TASK CONTEXT
*******************************************************************************/

void do_work_one_ms() {

	// without the "register" qualifier, cache effects cause unpredictable runtime. //
	//register int iters = iterations;

	// without the "volatile" qualifier, GCC optimizes out the loop with sufficient optimization level. //
	//for (volatile int i=0; i < iters; i++);

	/* A 65536-int array gives a WSS of 256KB given 32-bit integers */
	volatile int nums[4096];

	for (int i=0; i < iterations_per_ms; i++) {
		for (int j=0; j < 4096; j++) {
			nums[j] += 1;
			nums[j] = nums[j] * 77;
		}
	}
}

void work_loop(int task_id, int job_no, int param) {

	for (int i=0; i < param; i++) {
		do_work_one_ms();
	}

}

void idle_function(int ignored1, int ignored2, int ignored3) {
	if (t_rdtsc() > time_zero) {
		fprintf(stderr,"Worker became available only after TIME_ZERO.\n");
		system("killall main");
		exit(1);
	}
	while(1) {
		sleep(1);
	}
}

unsigned long long ms_to_cycles(double msec) {
	return cycles_per_nanosecond * 1000000 * msec;
}

double cycles_to_ms(unsigned long long cycles) {
	return (cycles / cycles_per_nanosecond) / 1000000;
}
